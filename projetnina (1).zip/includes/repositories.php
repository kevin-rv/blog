<?php
require_once('bdd.php');

function getAuthors(){
    global $pdo;
    $authors =[];
    $sql = "SELECT name,id FROM authors order by name";
    $result = $pdo->query($sql);
    
    while ($row = $result->fetch()) {
        $authors[$row['id']] = $row['name'];
    }
    return $authors;
}

function getGenres(){
    global $pdo;
    $genres =[];
    $sql = "SELECT name,id FROM genres order by name";
    $result = $pdo->query($sql);
    while ($row = $result->fetch()) {
        $genres[$row['id']] = $row['name'];
    }
    return $genres;
}

function getPublicationYears(){
    global $pdo;
    $years =[];
    $sql = "SELECT DISTINCT publication_year FROM books order by publication_year";
    $result = $pdo->query($sql);
    while ($row = $result->fetch()) {
        $years[$row['publication_year']] = $row['publication_year'];
    }
    return $years;
}

function getBooks(){
    global $pdo;
    $books = [];
    $sql = '
        select
            b.id,
            b.title,
            a.name as author,
            b.publication_year,
            g.name as genre 
        from books b
        left join authors a on b.author_id = a.id
        left join genres g on b.genre_id = g.id
    ';
    $result = $pdo->query($sql);
    while ($row = $result->fetch()) {
        $books[$row['id']] = $row;
    }
    return $books;
}

function searchBooks($searchData) {
    global $pdo;

    $searchWhere = [];
    $searchValues = [];

    function getAnd($searchWhere){
        $and = '';
        if(count($searchWhere)>0){
            $and = ' and ';
        }
        return $and;
    }

    function getAlias($searchWhere){
        return ":d".count($searchWhere);
    }

    if(isset($searchData['search']) && !empty($searchData['search'])){
        $searchWhere[]='(';
        $searchArr= explode(' ', $searchData['search']);

        $or='';
        if(count($searchWhere)>1){
            $or = ' or ';
        }

        foreach($searchArr as $search){
            $alias=getAlias($searchWhere);
            $searchValues[$alias] = "%$search%";
            $searchWhere[] = "$or lower(title) like lower($alias)";
        }

        $searchWhere[]=')';
    }

    $advancedSearchLib=[
        'author' =>'author_id =',
        'genre' =>'genre_id =',
        'year' =>'publication_year =',
        'isbn' =>'isbn =',
        'pagesStart' =>'pages >=',
        'pagesEnd' =>'pages <=',
    ];

    foreach($advancedSearchLib as $key => $value){
        if(isset($searchData[$key]) && !empty($searchData[$key])){
            $alias=getAlias($searchWhere);
            $searchValues[$alias] = $searchData[$key];
            $searchWhere[] = getAnd($searchWhere)."$value $alias";
        }
    }


    $where = '';
    if(count($searchWhere)>0){
        $where =" where ".implode(' ',$searchWhere);
    }

    $sql = "
        select
            b.id,
            b.title,
            a.id as author_id,
            a.name as author,
            b.publication_year,
            g.id as genre_id,
            g.name as genre
        from books b
        left join authors a on b.author_id = a.id
        left join genres g on b.genre_id = g.id
        $where
    ";
    
    $query = $pdo->prepare($sql);
    $query->execute($searchValues);

    $books = [];
    while ($row = $query->fetch()) {
        $books[] = $row;
    }
    return $books;
}