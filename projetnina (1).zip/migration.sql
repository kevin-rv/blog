CREATE TABLE authors (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL
);

CREATE TABLE genres (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL
);

CREATE TABLE books (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    author_id INT NOT NULL,
    publication_year INT NOT NULL,
    genre_id INT NOT NULL,
    isbn VARCHAR(13) UNIQUE NOT NULL,
    page_count INT,
    added_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (author_id) REFERENCES authors(id),
    FOREIGN KEY (genre_id) REFERENCES genres(id)
);

INSERT INTO authors (name) VALUES
('Harper Lee'),
('George Orwell'),
('F. Scott Fitzgerald'),
('J.D. Salinger'),
('J.R.R. Tolkien'),
('Ray Bradbury'),
('Jane Austen'),
('Anne Frank'),
('Stephen King'),
('Richard Dawkins');

INSERT INTO genres (name) VALUES
('Fiction'),
('Non-Fiction'),
('Science Fiction'),
('Fantasy'),
('Mystery'),
('Biography'),
('History'),
('Romance'),
('Horror'),
('Self-Help');

INSERT INTO books (title, author_id, publication_year, genre_id, isbn, page_count) VALUES
('To Kill a Mockingbird', 1, 1960, 1, '9780061120084', 281),
('1984', 2, 1949, 3, '9780451524935', 328),
('The Great Gatsby', 3, 1925, 1, '9780743273565', 180),
('The Catcher in the Rye', 4, 1951, 1, '9780316769488', 214),
('The Hobbit', 5, 1937, 4, '9780547928227', 310),
('Fahrenheit 451', 6, 1953, 3, '9781451673319', 194),
('Pride and Prejudice', 7, 1813, 8, '9781503290563', 279),
('The Diary of a Young Girl', 8, 1947, 6, '9780553296983', 283),
('The Shining', 9, 1977, 9, '9780307743657', 447),
('The Selfish Gene', 10, 1976, 10, '9780198788607', 360);