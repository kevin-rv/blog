<?php require_once('header.php'); ?>

<main>
    <h2>Accueil</h2>
    <p>Bienvenue sur la page d'accueil de notre bibliothèque. Ici, vous pouvez trouver des informations sur nos services, rechercher des livres et obtenir des renseignements.</p>
</main>

<?php require_once('footer.php'); ?>