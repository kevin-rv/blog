<?php 
require_once('header.php');
require_once('includes/repositories.php');


$books = getBooks($pdo);

$bookLines = '';
foreach ($books as $key => $value) {
    $bookLines.="
        <tr>
            <td class='title'>$value[title]</td>
            <td class='author'>$value[author]</td>
            <td class='publication_year'>$value[publication_year]</td>
            <td class='genre'>$value[genre]</td>
        </tr>
    ";
}

echo '
    <main>
    <h2>Liste des livres</h2>
    <table class="booklist">
        <thead>
            <tr>
                <th>Titre</th>
                <th>Auteur</th>
                <th>Année</th>
                <th>Genre</th>
            </tr>
        </thead>
        <tbody>'.$bookLines.'</tbody>
    </table>
</main>';

 require_once('footer.php');