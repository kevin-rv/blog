<?php
require_once('../includes/repositories.php');
$command=$_GET['command'];

if($command==='searchbook'){
    $search = json_decode($_GET['search'],true);
    $books = searchBooks($search);
    
    echo json_encode(["status"=>1,"data"=>$books]);
    return;
}

// FALLBACK
echo json_encode(["status"=>0,"msg"=>"Invalid command"]);
