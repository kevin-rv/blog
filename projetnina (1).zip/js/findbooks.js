const form=document.querySelector('.searchform');
getFormValues=()=>{
    let data={}
    for(let i=0,len=form.elements.length; i<len; i++){
        if(form.elements[i].tagName=== 'BUTTON' || form.elements[i].name=== 'advancedSearch' || !form.elements[i].value.length)
            continue

        data[form.elements[i].name]=form.elements[i].value
        
    }

    return data
}

const getBooks=async()=>{
    let search=getFormValues()
    if(Object.keys(search).length===0)
        return

    search=JSON.stringify(search)

    const data=await fetch(`./bridges/searchbooks.php?command=searchbook&search=${search}`)
    const books=await data.json()
    return books
}


const btn=document.querySelector('#launchsearch');
btn.addEventListener('click', e=>{
    e.preventDefault()
    getBooks().then(books=>{
        console.log(books)
    })

})