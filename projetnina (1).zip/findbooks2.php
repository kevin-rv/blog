<?php
require_once('header.php');
require_once('includes/repositories.php');

$authors = getAuthors();
$genres = getGenres();
$years = getPublicationYears();

function getSelectOptions($array) {
    $options = '<option value="">Tous</option>';
    foreach ($array as $key => $value) {
        $options .= "<option value='$key'>$value</option>";
    }
    return $options;
}


echo '
    <main>
        <h2>ICI ON TROUVE DES LIVRES !</h2>
        <form class="searchform">
            <div>Rechercher un livre</div>

            <div class="sb_inpbox">
                <input type="text" name="search" placeholder="Titre">
                <div class="advanced_search">
                    <input type="checkbox" name="advancedSearch" id="advanced_search" value="0">
                    <label for="advanced_search">Recherche avancée</label>
                </div>
            </div>

            <div class="advanced_search_options">
                <div class="aso_box">
                    <label for="author">Auteur</label>
                    <select name="author" id="author">'.getSelectOptions($authors).'</select>
                </div>
                <div class="aso_box">
                    <label for="genre">Genre</label>
                    <select name="genre" id="genre">'.getSelectOptions($genres).'</select>
                </div>
                <div class="aso_box">
                    <label for="genre">Publication</label>
                    <select name="year" id="year">'.getSelectOptions($years).'</select>
                </div>
                <div class="aso_box">
                    <label for="isbn">ISBN</label>
                    <input type="text" name="isbn" id="isbn" placeholder="9780547928227">
                </div>
                <div class="aso_box">
                    <label for="pagesstart">Entre</label>
                    <input type="text" class="searchpages" name="pagesStart" id="pagesstart">
                    <span for="pagesend">et</span>
                    <input type="text" class="searchpages" name="pagesEnd" id="pagesend">
                    <span>pages</span>
                </div>
            </div>

            <button id="launchsearch">Rechercher</button>
        </form>
        <div class="searchresults"></div>
    </main>

    <script src="js/findbooks.js"></script>
';

require_once('footer.php');