<nav>
    <ul>
        <li><a href="./">Accueil</a></li>
        <li><a href="booklist.php">Liste des livres</a></li>
        <li><a href="findbooks.php">Trouver un livre</a></li>
        <li><a href="info.php">Renseignement</a></li>
    </ul>
</nav>