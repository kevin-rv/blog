<?php require_once('header.php'); ?>

<main>
    <h2>ICI ON TROUVE DES LIVRES !</h2>
</main>


<?php require_once('footer.php'); ?>