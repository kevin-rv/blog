<?php require_once('header.php'); ?>
<main>
    <h2>ICI CE SONT LES INFOS ! </h2>
</main>



<?php require_once('footer.php'); ?>
